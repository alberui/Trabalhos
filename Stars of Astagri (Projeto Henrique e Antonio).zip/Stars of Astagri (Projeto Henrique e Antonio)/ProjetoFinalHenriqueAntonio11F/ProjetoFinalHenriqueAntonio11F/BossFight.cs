﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{

    public partial class BossFight : Form
    {
        System.Media.SoundPlayer bosstheme = new System.Media.SoundPlayer(@"C:\Windows\Media\KarebraBossFight.wav");

        bool direita, esquerda, baixo, cima, atirar, perdeu;
        int velocidadejogador = 10;
        int velocidadeinimigo = 20;
        int velocidadebala;
        public static int pontuacao;
        int vida = 100;
        int vidaboss = 100;

        int velocidadeboss = 40;
        //int velocidadeboss2 = 40;

        public static int pointreceber = Shop.pointnum;

        Random rambo = new Random();

        private void gametimer(object sender, EventArgs e)
        {
            


            //velocidade do inimigo
            enemy1.Left += velocidadeinimigo;
            enemy2.Top += velocidadeinimigo;
            enemy3.Top += velocidadeinimigo;
            enemy4.Top += velocidadeinimigo;
            enemy5.Left -= velocidadeinimigo;
            enemy6.Left -= velocidadeinimigo;
            enemy7.Left += velocidadeinimigo;
            enemy8.Top += velocidadeinimigo;
            
            KarebraBoss.Left += velocidadeboss;
            //KarebraBoss.Left -= velocidadeboss2;


            //quando perde
            /* if (enemy1.Top > 630 || enemy2.Top > 630 || enemy3.Top > 630)
             {
                 gameover();
             }*/


            //movimento do jogador
            if (esquerda == true && jogador.Left > 0)
            {
                jogador.Left -= velocidadejogador;
            }
            if (direita == true && jogador.Left < 454)
            {
                jogador.Left += velocidadejogador;
            }
            if (cima == true && jogador.Top > 0)
            {
                jogador.Top -= velocidadejogador;
            }
            if (baixo == true && jogador.Top < 519)
            {
                jogador.Top += velocidadejogador;
            }
            //jogador atirar
            if (atirar == true)
            {
                velocidadebala = 60;
                bala.Top -= velocidadebala;
            }
            else
            {
                velocidadebala = 0;
                bala.Left = -300;
            }

            if (bala.Top < -30)
            {
                atirar = false;
            }
            //detetar colisao entre a bala e os enimigos
            if (bala.Bounds.IntersectsWith(enemy1.Bounds))
            {
                enemy1.Top = -450;
                enemy1.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy2.Bounds))
            {
                enemy2.Top = -650;
                enemy2.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy3.Bounds))
            {
                enemy3.Top = -750;
                enemy3.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy4.Bounds))
            {
                enemy4.Top = -750;
                enemy4.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy5.Bounds))
            {
                enemy5.Top = -750;
                enemy5.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy6.Bounds))
            {
                enemy6.Top = -750;
                enemy6.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy7.Bounds))
            {
                enemy7.Top = -750;
                enemy7.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy8.Bounds))
            {
                enemy8.Top = -750;
                enemy8.Left = rambo.Next(20, 450);
                atirar = false;
            }

            if (bala.Bounds.IntersectsWith(KarebraBoss.Bounds))
            {
                vidaboss -= 2;
                atirar = false;
            }

            if (vidaboss > 1)
            {
                BossBar.Value = Convert.ToInt32(vidaboss);
            }

          

            bool desbugaforms = false;
            foreach(Form f in Application.OpenForms)
            {
                if (f.Text == "Stars of Astagri - Congratulations")
                {
                    desbugaforms = true;
                    f.BringToFront();
                    break;
                }
            }

            if (vidaboss < 0 && desbugaforms == false)
            {
                var win = new YouWin();
                win.Show();
                this.Hide();
            }

            if (vidaboss > 0 && vidaboss < 51)
            {
                velocidadeinimigo = 30;
            }



            if (vida > 1)
            {
                progressBar1.Value = Convert.ToInt32(vida);
            }
            if (jogador.Bounds.IntersectsWith(enemy1.Bounds) || jogador.Bounds.IntersectsWith(enemy2.Bounds) || jogador.Bounds.IntersectsWith(enemy3.Bounds) || jogador.Bounds.IntersectsWith(enemy4.Bounds) || jogador.Bounds.IntersectsWith(enemy5.Bounds) || jogador.Bounds.IntersectsWith(enemy6.Bounds) || jogador.Bounds.IntersectsWith(enemy7.Bounds) || jogador.Bounds.IntersectsWith(enemy8.Bounds) || jogador.Bounds.IntersectsWith(KarebraBoss.Bounds))
            {
                vida -= 2;
            }
            if (jogador.Bounds.IntersectsWith(enemy1.Bounds) || jogador.Bounds.IntersectsWith(enemy2.Bounds) || jogador.Bounds.IntersectsWith(enemy3.Bounds) || jogador.Bounds.IntersectsWith(enemy4.Bounds) || jogador.Bounds.IntersectsWith(enemy5.Bounds) || jogador.Bounds.IntersectsWith(enemy6.Bounds) || jogador.Bounds.IntersectsWith(enemy7.Bounds) || jogador.Bounds.IntersectsWith(enemy8.Bounds) || jogador.Bounds.IntersectsWith(KarebraBoss.Bounds))
            {
               /* System.Media.SoundPlayer colisao = new System.Media.SoundPlayer(@"c:\Windows\Media\colisao.wav");
                colisao.PlaySync();*/
            }
                if (vida <= 0)
            {
                gameover();
            }
                
            //nascimento random dos inimigos/balas
            if (enemy1.Left > 500)
            {
                enemy1.Left = -60;
                enemy1.Top = rambo.Next(70, 450);
            }
            if (enemy2.Top > 600)
            {
                enemy2.Top = -650;
                enemy2.Left = rambo.Next(20, 450);
            }
            if (enemy3.Top > 600)
            {
                enemy3.Top = -650;
                enemy3.Left = rambo.Next(20, 450);
            }
            if (enemy4.Top > 600)
            {
                enemy4.Top = -650;
                enemy4.Left = rambo.Next(20, 450);
            }
            if (enemy5.Left < -100)
            {
                enemy5.Left = 456;
                enemy5.Top = rambo.Next(70, 450);
            }
            if (enemy6.Left < -100)
            {
                enemy6.Left = 456;
                enemy6.Top = rambo.Next(70, 450);
            }
            if (enemy7.Left > 500)
            {
                enemy7.Left = -60;
                enemy7.Top = rambo.Next(70, 450);
            }
            if (enemy8.Top > 600)
            {
                enemy8.Top = -650;
                enemy8.Left = rambo.Next(20, 450);
            }

            if (KarebraBoss.Left < -100)
            {
                KarebraBoss.Left = 456;
            }
            if (KarebraBoss.Left > 456)
            {
                KarebraBoss.Left = -75;
            }

            //Program.pointreceber = Program.pointreceber + pontuacao;
        }

        public BossFight()
        {
            InitializeComponent();
            bosstheme.PlayLooping();
            resetgame();
        }

        private void jogador_Click(object sender, EventArgs e)
        {

        }

        private void enemy2_Click(object sender, EventArgs e)
        {

        }

        private void PlayerMovement(object sender, KeyEventArgs e)
        {
            //teclas para movimentar
            if (e.KeyCode == Keys.Left)
            {
                esquerda = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                baixo = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                cima = true;
            }
            if (e.KeyCode == Keys.Space)
            {
                /*System.Media.SoundPlayer laser = new System.Media.SoundPlayer(@"c:\Windows\Media\laser.wav");
                laser.PlaySync();*/
            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click_1(object sender, EventArgs e)
        {

        }

        private void bala_Click(object sender, EventArgs e)
        {

        }

        private void ComeçarBoss_Click(object sender, EventArgs e)
        {
            var boss = new BossFight();
            boss.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void PlayerMove(object sender, KeyEventArgs e)
        {
            //movimento outra vez mas quando nao clica acho eu
            if (e.KeyCode == Keys.Left)
            {
                esquerda = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                baixo = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                cima = false;
            }
            //tecla para atirar
            if (e.KeyCode == Keys.Space && atirar == false)
            {
                atirar = true;

                bala.Top = jogador.Top + 30;
                bala.Left = jogador.Left + (jogador.Width / 2);
            }
            //começar outra vez (tenta fazer com que vai para o menu principal)
            if (e.KeyCode == Keys.Enter && perdeu == true)
            {
                resetgame();
                perdeutext.Visible = false;
                vida = 100;
            }
            else if (e.KeyCode == Keys.Escape && perdeu == true)
            {
                var menu = new Form1();
                menu.Show();
                this.Hide();
            }

        }
        private void resetgame()
        {
            timer.Start();
            velocidadeinimigo = 20;

            enemy1.Left = rambo.Next(20, 450);
            enemy2.Left = rambo.Next(20, 450);
            enemy3.Left = rambo.Next(20, 450);
            enemy4.Left = rambo.Next(20, 450);
            enemy5.Left = rambo.Next(20, 450);

            enemy1.Top = rambo.Next(0, 200) * -1;
            enemy2.Top = rambo.Next(0, 500) * -1;
            enemy3.Top = rambo.Next(0, 700) * -1;
            enemy4.Top = rambo.Next(0, 700) * -1;
            enemy5.Top = rambo.Next(0, 700) * -1;

            velocidadebala = 0;
            bala.Left = -300;
            atirar = false;

        }

        private void gameover()
        {
            perdeu = true;
            timer.Stop();
            perdeutext.Visible = true;
        }
        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                esquerda = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = false;
            }
            if (e.KeyCode == Keys.Space && atirar == false)
            {
                atirar = true;

                bala.Top = jogador.Top - 30;
                bala.Left = jogador.Left + (jogador.Width / 2);

            }
        }
    }
}