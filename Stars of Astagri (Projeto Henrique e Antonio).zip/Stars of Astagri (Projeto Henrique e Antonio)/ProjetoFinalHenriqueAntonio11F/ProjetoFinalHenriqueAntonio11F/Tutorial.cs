﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{
    public partial class Tutorial : Form
    {
        System.Media.SoundPlayer tutorialtheme = new System.Media.SoundPlayer(@"C:\Windows\Media\MusicaTutorial.wav");
        public Tutorial()
        {
            InitializeComponent();
            tutorialtheme.PlayLooping();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click.Play();
            var menu = new Form1();
            menu.Show();
            this.Close();
        }
    }
}
