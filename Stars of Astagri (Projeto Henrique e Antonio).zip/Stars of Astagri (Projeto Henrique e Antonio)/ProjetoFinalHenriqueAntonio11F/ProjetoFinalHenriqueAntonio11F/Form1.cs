﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{
    public partial class Form1 : Form
    {
       public static System.Media.SoundPlayer menutheme = new System.Media.SoundPlayer(@"C:\Windows\Media\MenuMusica.wav");

        public Form1()
        {
            InitializeComponent();

            menutheme.PlayLooping();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var game = new Form2();
            game.Show();
            this.Hide();
            System.Media.SoundPlayer click5 = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click5.Play();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click4 = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click4.Play();
            var shop = new Shop();
            shop.Show();
            this.Hide();
        }

        private void ExitGame_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click3 = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click3.Play();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click2 = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click2.Play();
            var noob = new Tutorial();
            noob.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            click.Play();
            var tutorial = new Tutorial();
            tutorial.Show();
            this.Hide();
            
        }
    }
}
