﻿namespace ProjetoFinalHenriqueAntonio11F
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.points = new System.Windows.Forms.Label();
            this.shoptimer = new System.Windows.Forms.Timer(this.components);
            this.custopoints = new System.Windows.Forms.Label();
            this.erropontos1 = new System.Windows.Forms.Label();
            this.errocusto2 = new System.Windows.Forms.Label();
            this.errocusto3 = new System.Windows.Forms.Label();
            this.errocusto4 = new System.Windows.Forms.Label();
            this.errocusto5 = new System.Windows.Forms.Label();
            this.errocusto7 = new System.Windows.Forms.Label();
            this.errocusto6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.testepontos = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(234, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Shop";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(12, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 71);
            this.button1.TabIndex = 1;
            this.button1.Text = "Speed x2";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(12, 201);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(185, 71);
            this.button2.TabIndex = 3;
            this.button2.Text = "Speed x3";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(12, 278);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(185, 65);
            this.button3.TabIndex = 4;
            this.button3.Text = "Speed x4";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(12, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(100, 39);
            this.button4.TabIndex = 5;
            this.button4.Text = "Voltar atrás";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(12, 349);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(185, 71);
            this.button5.TabIndex = 6;
            this.button5.Text = "Speed x5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(12, 426);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(185, 71);
            this.button6.TabIndex = 7;
            this.button6.Text = "Speed x6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(395, 210);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(118, 71);
            this.button7.TabIndex = 8;
            this.button7.Text = "Score x2";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(395, 360);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(118, 71);
            this.button8.TabIndex = 9;
            this.button8.Text = " Score x3";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // points
            // 
            this.points.BackColor = System.Drawing.Color.Transparent;
            this.points.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.points.ForeColor = System.Drawing.Color.Aquamarine;
            this.points.Location = new System.Drawing.Point(320, 9);
            this.points.Name = "points";
            this.points.Size = new System.Drawing.Size(193, 26);
            this.points.TabIndex = 10;
            this.points.Text = "Points:";
            // 
            // shoptimer
            // 
            this.shoptimer.Enabled = true;
            this.shoptimer.Tick += new System.EventHandler(this.gameshoptimer);
            // 
            // custopoints
            // 
            this.custopoints.AutoSize = true;
            this.custopoints.BackColor = System.Drawing.Color.Transparent;
            this.custopoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custopoints.ForeColor = System.Drawing.Color.LightGreen;
            this.custopoints.Location = new System.Drawing.Point(204, 147);
            this.custopoints.Name = "custopoints";
            this.custopoints.Size = new System.Drawing.Size(93, 20);
            this.custopoints.TabIndex = 11;
            this.custopoints.Text = "6870 Points";
            this.custopoints.Click += new System.EventHandler(this.custopoints_Click);
            // 
            // erropontos1
            // 
            this.erropontos1.AutoSize = true;
            this.erropontos1.BackColor = System.Drawing.Color.Transparent;
            this.erropontos1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.erropontos1.ForeColor = System.Drawing.Color.Red;
            this.erropontos1.Location = new System.Drawing.Point(208, 171);
            this.erropontos1.Name = "erropontos1";
            this.erropontos1.Size = new System.Drawing.Size(173, 20);
            this.erropontos1.TabIndex = 12;
            this.erropontos1.Text = "Pontos Insuficientes";
            this.erropontos1.Visible = false;
            // 
            // errocusto2
            // 
            this.errocusto2.AutoSize = true;
            this.errocusto2.BackColor = System.Drawing.Color.Transparent;
            this.errocusto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto2.ForeColor = System.Drawing.Color.Red;
            this.errocusto2.Location = new System.Drawing.Point(208, 252);
            this.errocusto2.Name = "errocusto2";
            this.errocusto2.Size = new System.Drawing.Size(173, 20);
            this.errocusto2.TabIndex = 13;
            this.errocusto2.Text = "Pontos Insuficientes";
            this.errocusto2.Visible = false;
            // 
            // errocusto3
            // 
            this.errocusto3.AutoSize = true;
            this.errocusto3.BackColor = System.Drawing.Color.Transparent;
            this.errocusto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto3.ForeColor = System.Drawing.Color.Red;
            this.errocusto3.Location = new System.Drawing.Point(208, 323);
            this.errocusto3.Name = "errocusto3";
            this.errocusto3.Size = new System.Drawing.Size(173, 20);
            this.errocusto3.TabIndex = 14;
            this.errocusto3.Text = "Pontos Insuficientes";
            this.errocusto3.Visible = false;
            // 
            // errocusto4
            // 
            this.errocusto4.AutoSize = true;
            this.errocusto4.BackColor = System.Drawing.Color.Transparent;
            this.errocusto4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto4.ForeColor = System.Drawing.Color.Red;
            this.errocusto4.Location = new System.Drawing.Point(208, 400);
            this.errocusto4.Name = "errocusto4";
            this.errocusto4.Size = new System.Drawing.Size(173, 20);
            this.errocusto4.TabIndex = 15;
            this.errocusto4.Text = "Pontos Insuficientes";
            this.errocusto4.Visible = false;
            // 
            // errocusto5
            // 
            this.errocusto5.AutoSize = true;
            this.errocusto5.BackColor = System.Drawing.Color.Transparent;
            this.errocusto5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto5.ForeColor = System.Drawing.Color.Red;
            this.errocusto5.Location = new System.Drawing.Point(208, 477);
            this.errocusto5.Name = "errocusto5";
            this.errocusto5.Size = new System.Drawing.Size(173, 20);
            this.errocusto5.TabIndex = 16;
            this.errocusto5.Text = "Pontos Insuficientes";
            this.errocusto5.Visible = false;
            // 
            // errocusto7
            // 
            this.errocusto7.BackColor = System.Drawing.Color.Transparent;
            this.errocusto7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto7.ForeColor = System.Drawing.Color.Red;
            this.errocusto7.Location = new System.Drawing.Point(395, 454);
            this.errocusto7.Name = "errocusto7";
            this.errocusto7.Size = new System.Drawing.Size(118, 44);
            this.errocusto7.TabIndex = 17;
            this.errocusto7.Text = "Pontos Insuficientes";
            this.errocusto7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.errocusto7.Visible = false;
            // 
            // errocusto6
            // 
            this.errocusto6.BackColor = System.Drawing.Color.Transparent;
            this.errocusto6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errocusto6.ForeColor = System.Drawing.Color.Red;
            this.errocusto6.Location = new System.Drawing.Point(391, 302);
            this.errocusto6.Name = "errocusto6";
            this.errocusto6.Size = new System.Drawing.Size(118, 44);
            this.errocusto6.TabIndex = 18;
            this.errocusto6.Text = "Pontos Insuficientes";
            this.errocusto6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.errocusto6.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.LightGreen;
            this.label2.Location = new System.Drawing.Point(208, 228);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "12090 Points";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.LightGreen;
            this.label3.Location = new System.Drawing.Point(208, 302);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "20100 Points";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.LightGreen;
            this.label4.Location = new System.Drawing.Point(208, 376);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "50400 Points";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.LightGreen;
            this.label5.Location = new System.Drawing.Point(208, 453);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "86740 Points";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.LightGreen;
            this.label6.Location = new System.Drawing.Point(402, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "132430 Points";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.LightGreen;
            this.label7.Location = new System.Drawing.Point(395, 434);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 20);
            this.label7.TabIndex = 24;
            this.label7.Text = "4000000 Points";
            // 
            // testepontos
            // 
            this.testepontos.Location = new System.Drawing.Point(440, 59);
            this.testepontos.Name = "testepontos";
            this.testepontos.Size = new System.Drawing.Size(73, 20);
            this.testepontos.TabIndex = 25;
            this.testepontos.Visible = false;
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.fundozaomenuprincipal;
            this.ClientSize = new System.Drawing.Size(525, 578);
            this.Controls.Add(this.testepontos);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.errocusto6);
            this.Controls.Add(this.errocusto7);
            this.Controls.Add(this.errocusto5);
            this.Controls.Add(this.errocusto4);
            this.Controls.Add(this.errocusto3);
            this.Controls.Add(this.errocusto2);
            this.Controls.Add(this.erropontos1);
            this.Controls.Add(this.custopoints);
            this.Controls.Add(this.points);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Shop";
            this.Text = "Stars of Astagri";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MenuNow);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GoBack);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label points;
        private System.Windows.Forms.Timer shoptimer;
        private System.Windows.Forms.Label custopoints;
        private System.Windows.Forms.Label erropontos1;
        private System.Windows.Forms.Label errocusto2;
        private System.Windows.Forms.Label errocusto3;
        private System.Windows.Forms.Label errocusto4;
        private System.Windows.Forms.Label errocusto5;
        private System.Windows.Forms.Label errocusto7;
        private System.Windows.Forms.Label errocusto6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox testepontos;
    }
}