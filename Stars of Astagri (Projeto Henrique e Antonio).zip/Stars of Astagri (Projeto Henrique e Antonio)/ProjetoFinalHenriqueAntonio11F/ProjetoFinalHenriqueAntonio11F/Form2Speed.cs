﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{
    public partial class Form2speed : Form
    {
        bool direita, esquerda, baixo, cima, atirar, perdeu;
        int velocidadejogador = 13;
        int velocidadeinimigo = 6;
        int velocidadebala;
        int pontuacao;
        int vida = 100;
        Random rambo = new Random();

        private void gametimer(object sender, EventArgs e)
        {
            scoretext.Text = "Score: " + pontuacao;


            //velocidade do inimigo
            enemy1.Top += velocidadeinimigo;
            enemy2.Top += velocidadeinimigo;
            enemy3.Top += velocidadeinimigo;
            enemy4.Top += velocidadeinimigo;
            enemy5.Top += velocidadeinimigo;

            //quando perde
            /* if (enemy1.Top > 630 || enemy2.Top > 630 || enemy3.Top > 630)
             {
                 gameover();
             }*/


            //movimento do jogador
            if (esquerda == true && jogador.Left > 0)
            {
                jogador.Left -= velocidadejogador;
            }
            if (direita == true && jogador.Left < 454)
            {
                jogador.Left += velocidadejogador;
            }
            if (cima == true && jogador.Top > 0)
            {
                jogador.Top -= velocidadejogador;
            }
            if (baixo == true && jogador.Top < 519)
            {
                jogador.Top += velocidadejogador;
            }
            //jogador atirar
            if (atirar == true)
            {
                velocidadebala = 60;
                bala.Top -= velocidadebala;
            }
            else
            {
                velocidadebala = 0;
                bala.Left = -300;
            }

            if (bala.Top < -30)
            {
                atirar = false;
            }
            //detetar colisao entre a bala e os enimigos
            if (bala.Bounds.IntersectsWith(enemy1.Bounds))
            {
                pontuacao += 1;
                enemy1.Top = -450;
                enemy1.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy2.Bounds))
            {
                pontuacao += 1;
                enemy2.Top = -650;
                enemy2.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy3.Bounds))
            {
                pontuacao += 1;
                enemy3.Top = -750;
                enemy3.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy4.Bounds))
            {
                pontuacao += 1;
                enemy4.Top = -750;
                enemy4.Left = rambo.Next(20, 450);
                atirar = false;
            }
            if (bala.Bounds.IntersectsWith(enemy5.Bounds))
            {
                pontuacao += 1;
                enemy5.Top = -750;
                enemy5.Left = rambo.Next(20, 450);
                atirar = false;
            }

            if (pontuacao == 10)
            {
                velocidadeinimigo = 9;
            }

            if (pontuacao == 20)
            {
                velocidadeinimigo = 12;
            }

            if (pontuacao == 30)
            {
                velocidadeinimigo = 15;
            }

            if (pontuacao == 40)
            {
                velocidadeinimigo = 20;
            }

            //boss fight
            if (pontuacao == 50)
            {
                timer.Stop();
                bosswarning.Visible = true;
                ComeçarBoss.Visible = true;
            }

            if (vida > 1)
            {
                progressBar1.Value = Convert.ToInt32(vida);
            }
            if (jogador.Bounds.IntersectsWith(enemy1.Bounds) || jogador.Bounds.IntersectsWith(enemy2.Bounds) || jogador.Bounds.IntersectsWith(enemy3.Bounds) || jogador.Bounds.IntersectsWith(enemy4.Bounds) || jogador.Bounds.IntersectsWith(enemy5.Bounds))
            {
                vida -= 2;
            }
            if (jogador.Bounds.IntersectsWith(enemy1.Bounds) || jogador.Bounds.IntersectsWith(enemy2.Bounds) || jogador.Bounds.IntersectsWith(enemy3.Bounds) || jogador.Bounds.IntersectsWith(enemy4.Bounds) || jogador.Bounds.IntersectsWith(enemy5.Bounds))
            {
                System.Media.SoundPlayer colisao = new System.Media.SoundPlayer(@"c:\Windows\Media\colisao.wav");
                colisao.Play();
            }
            if (vida <= 0)
            {
                gameover();
            }
            if (enemy1.Top > 600)
            {
                enemy1.Top = -650;
                enemy1.Left = rambo.Next(20, 450);
            }
            if (enemy2.Top > 600)
            {
                enemy2.Top = -650;
                enemy2.Left = rambo.Next(20, 450);
            }
            if (enemy3.Top > 600)
            {
                enemy3.Top = -650;
                enemy3.Left = rambo.Next(20, 450);
            }
            if (enemy4.Top > 600)
            {
                enemy4.Top = -650;
                enemy4.Left = rambo.Next(20, 450);
            }
            if (enemy5.Top > 600)
            {
                enemy5.Top = -650;
                enemy5.Left = rambo.Next(20, 450);
            }

            Program.pointreceber = Program.pointreceber + pontuacao;
        }

        public Form2speed()
        {
            InitializeComponent();
            resetgame();
        }

        private void jogador_Click(object sender, EventArgs e)
        {

        }

        private void enemy2_Click(object sender, EventArgs e)
        {

        }

        private void PlayerMovement(object sender, KeyEventArgs e)
        {
            //teclas para movimentar
            if (e.KeyCode == Keys.Left)
            {
                esquerda = true;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                baixo = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                cima = true;
            }
            if (e.KeyCode == Keys.Space)
            {
                System.Media.SoundPlayer laser = new System.Media.SoundPlayer(@"c:\Windows\Media\laser.wav");
                laser.Play();
            }
        }

        private void ComeçarBoss_Click(object sender, EventArgs e)
        {
            var boss = new BossFight();
            boss.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void PlayerMove(object sender, KeyEventArgs e)
        {
            //movimento outra vez mas quando nao clica acho eu
            if (e.KeyCode == Keys.Left)
            {
                esquerda = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                baixo = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                cima = false;
            }
            //tecla para atirar
            if (e.KeyCode == Keys.Space && atirar == false)
            {
                atirar = true;

                bala.Top = jogador.Top + 30;
                bala.Left = jogador.Left + (jogador.Width / 2);
            }
            //começar outra vez (tenta fazer com que vai para o menu principal)
            if (e.KeyCode == Keys.Enter && perdeu == true)
            {
                resetgame();
                perdeutext.Visible = false;
                vida = 100;
            }
            else if (e.KeyCode == Keys.Escape && perdeu == true)
            {
                var menu = new Form1();
                menu.Show();
                this.Hide();
            }

        }
        private void resetgame()
        {
            timer.Start();
            velocidadeinimigo = 7;

            enemy1.Left = rambo.Next(20, 450);
            enemy2.Left = rambo.Next(20, 450);
            enemy3.Left = rambo.Next(20, 450);
            enemy4.Left = rambo.Next(20, 450);
            enemy5.Left = rambo.Next(20, 450);

            enemy1.Top = rambo.Next(0, 200) * -1;
            enemy2.Top = rambo.Next(0, 500) * -1;
            enemy3.Top = rambo.Next(0, 700) * -1;
            enemy4.Top = rambo.Next(0, 700) * -1;
            enemy5.Top = rambo.Next(0, 700) * -1;

            pontuacao = 0;
            velocidadebala = 0;
            bala.Left = -300;
            atirar = false;

            scoretext.Text = "Score: " + pontuacao;
        }

        private void gameover()
        {
            perdeu = true;
            timer.Stop();
            perdeutext.Visible = true;
        }
        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                esquerda = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                direita = false;
            }
            if (e.KeyCode == Keys.Space && atirar == false)
            {
                atirar = true;

                bala.Top = jogador.Top - 30;
                bala.Left = jogador.Left + (jogador.Width / 2);

            }
        }
    }
}