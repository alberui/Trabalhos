﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{
    public partial class Shop : Form
    {
        public static int pointnum = 0;

        System.Media.SoundPlayer shoptheme = new System.Media.SoundPlayer(@"C:\Windows\Media\MusicaLoja.wav");
        //public static int pointrecev = Form2.pontuacao;

        public Shop()
        {
            InitializeComponent();
            shoptheme.PlayLooping();
            pointreceber();
 
        }

        //compra dos bonus de velocidade e de pontos
        private void button1_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 6870)
            {
                var speedx2 = new Form2speed();
                speedx2.Show();
                this.Hide();
                pointnum = pointnum - 6870;
            }
            else
            {
                erropontos1.Visible = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 12090)
            {
                var speedx3 = new Form2Late();
                speedx3.Show();
                this.Hide();
                pointnum = pointnum - 12090;
            }
            else
            {
                errocusto2.Visible = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 20100)
            {
                var speedx4 = new Form2Double();
                speedx4.Show();
                this.Hide();
                pointnum = pointnum - 20100;
            }
            else
            {
                errocusto3.Visible = true;
            }
        }

        private void GoBack(object sender, KeyPressEventArgs e)
        {

        }

        private void MenuNow(object sender, KeyEventArgs e)
        {
 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\click.wav");
            dinheiro.Play();
            var menu = new Form1();
            menu.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 50400)
            {
                var speedx5 = new Speedx5();
                speedx5.Show();
                this.Hide();
                pointnum = pointnum - 50400;
            }
            else
            {
                errocusto4.Visible = true; 
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 86740)
            {
                var speedx6 = new Speedx6();
                speedx6.Show();
                this.Hide();
                pointnum = pointnum - 86740;
            }
            else
            {
                errocusto5.Visible = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 132430)
            {
                var scorex2 = new Scorex2();
                scorex2.Show();
                this.Hide();
                pointnum = pointnum - 132430;
            }
            else
            {
                errocusto6.Visible = true;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer dinheiro = new System.Media.SoundPlayer(@"c:\Windows\Media\loja.wav");
            dinheiro.Play();
            if (pointnum >= 4000000)
            {
                var scorex3 = new Scorex3();
                scorex3.Show();
                this.Hide();
                pointnum = pointnum - 4000000;
            }
            else
            {
                errocusto7.Visible = true;
            }
        }

        private void gameshoptimer(object sender, EventArgs e)
        {
            points.Text = "Points: " + pointnum;

            pointnum = Program.pointreceber + Program.pointrecev;
 
        }

        private void custopoints_Click(object sender, EventArgs e)
        {

        }
        public static void pointreceber()
        {
            //pointnum = Program.pointrecev;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        public void savevalue()
        {
            
        }
    }
    
}
