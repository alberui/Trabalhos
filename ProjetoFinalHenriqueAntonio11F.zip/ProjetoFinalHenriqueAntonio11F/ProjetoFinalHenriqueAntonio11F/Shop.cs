﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoFinalHenriqueAntonio11F
{
    public partial class Shop : Form
    {
        public static int pointnum;

        //public static int pointrecev = Form2.pontuacao;

        public Shop()
        {
            InitializeComponent();
            pointreceber();
 
        }

        //compra dos bonus de velocidade e de pontos
        private void button1_Click(object sender, EventArgs e)
        {
            if (pointnum >= 50)
            {
                var speedx2 = new Form2speed();
                speedx2.Show();
                this.Hide();
                pointnum = pointnum - 50;
            }
            else
            {
                erropontos1.Visible = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pointnum >= 84)
            {
                var speedx3 = new Form2Late();
                speedx3.Show();
                this.Hide();
                pointnum = pointnum - 84;
            }
            else
            {
                errocusto2.Visible = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (pointnum >= 127)
            {
                var speedx4 = new Form2Double();
                speedx4.Show();
                this.Hide();
                pointnum = pointnum - 127;
            }
            else
            {
                errocusto3.Visible = true;
            }
        }

        private void GoBack(object sender, KeyPressEventArgs e)
        {

        }

        private void MenuNow(object sender, KeyEventArgs e)
        {
 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var menu = new Form1();
            menu.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (pointnum >= 200)
            {
                var speedx5 = new Speedx5();
                speedx5.Show();
                this.Hide();
                pointnum = pointnum - 200;
            }
            else
            {
                errocusto4.Visible = true; 
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (pointnum >= 355)
            {
                var speedx6 = new Speedx6();
                speedx6.Show();
                this.Hide();
                pointnum = pointnum - 355;
            }
            else
            {
                errocusto5.Visible = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (pointnum >= 500)
            {
                var scorex2 = new Scorex2();
                scorex2.Show();
                this.Hide();
                pointnum = pointnum - 500;
            }
            else
            {
                errocusto6.Visible = true;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (pointnum >= 4000)
            {
                var scorex3 = new Scorex3();
                scorex3.Show();
                this.Hide();
                pointnum = pointnum - 4000;
            }
            else
            {
                errocusto7.Visible = true;
            }
        }

        private void gameshoptimer(object sender, EventArgs e)
        {
            points.Text = "Points: " + pointnum;

            //pointnum = Program.pointrecev;
 
        }

        private void custopoints_Click(object sender, EventArgs e)
        {

        }
        public static void pointreceber()
        {
            pointnum = Program.pointrecev;
        }
    }
    
}
