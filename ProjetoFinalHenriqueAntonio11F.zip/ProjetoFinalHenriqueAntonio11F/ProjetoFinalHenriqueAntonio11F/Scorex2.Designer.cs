﻿namespace ProjetoFinalHenriqueAntonio11F
{
    partial class Scorex2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.scoretext = new System.Windows.Forms.Label();
            this.perdeutext = new System.Windows.Forms.Label();
            this.bala = new System.Windows.Forms.PictureBox();
            this.enemy3 = new System.Windows.Forms.PictureBox();
            this.enemy2 = new System.Windows.Forms.PictureBox();
            this.enemy1 = new System.Windows.Forms.PictureBox();
            this.jogador = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.bala)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jogador)).BeginInit();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 10;
            this.timer.Tick += new System.EventHandler(this.gametimer);
            // 
            // scoretext
            // 
            this.scoretext.BackColor = System.Drawing.Color.Transparent;
            this.scoretext.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoretext.ForeColor = System.Drawing.Color.White;
            this.scoretext.Location = new System.Drawing.Point(373, 3);
            this.scoretext.Name = "scoretext";
            this.scoretext.Size = new System.Drawing.Size(140, 28);
            this.scoretext.TabIndex = 1;
            this.scoretext.Text = "Score: 0";
            // 
            // perdeutext
            // 
            this.perdeutext.AutoSize = true;
            this.perdeutext.BackColor = System.Drawing.Color.Transparent;
            this.perdeutext.Font = new System.Drawing.Font("Impact", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.perdeutext.ForeColor = System.Drawing.Color.Red;
            this.perdeutext.Location = new System.Drawing.Point(60, 262);
            this.perdeutext.Name = "perdeutext";
            this.perdeutext.Size = new System.Drawing.Size(428, 108);
            this.perdeutext.TabIndex = 6;
            this.perdeutext.Text = "Game Over\r\nClique Enter para começar denovo.\r\nClique Esc para voltar para o menu." +
    "";
            this.perdeutext.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.perdeutext.Visible = false;
            // 
            // bala
            // 
            this.bala.BackColor = System.Drawing.Color.Transparent;
            this.bala.Image = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.beamlaser;
            this.bala.Location = new System.Drawing.Point(262, 446);
            this.bala.Name = "bala";
            this.bala.Size = new System.Drawing.Size(10, 28);
            this.bala.TabIndex = 5;
            this.bala.TabStop = false;
            // 
            // enemy3
            // 
            this.enemy3.BackColor = System.Drawing.Color.Transparent;
            this.enemy3.Image = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.navesoooh;
            this.enemy3.Location = new System.Drawing.Point(418, 86);
            this.enemy3.Name = "enemy3";
            this.enemy3.Size = new System.Drawing.Size(70, 71);
            this.enemy3.TabIndex = 4;
            this.enemy3.TabStop = false;
            // 
            // enemy2
            // 
            this.enemy2.BackColor = System.Drawing.Color.Transparent;
            this.enemy2.Image = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.navesoooh;
            this.enemy2.Location = new System.Drawing.Point(241, 96);
            this.enemy2.Name = "enemy2";
            this.enemy2.Size = new System.Drawing.Size(70, 71);
            this.enemy2.TabIndex = 3;
            this.enemy2.TabStop = false;
            this.enemy2.Click += new System.EventHandler(this.enemy2_Click);
            // 
            // enemy1
            // 
            this.enemy1.BackColor = System.Drawing.Color.Transparent;
            this.enemy1.Image = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.navesoooh;
            this.enemy1.Location = new System.Drawing.Point(66, 111);
            this.enemy1.Name = "enemy1";
            this.enemy1.Size = new System.Drawing.Size(70, 71);
            this.enemy1.TabIndex = 2;
            this.enemy1.TabStop = false;
            // 
            // jogador
            // 
            this.jogador.BackColor = System.Drawing.Color.Transparent;
            this.jogador.Image = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.planehehe;
            this.jogador.Location = new System.Drawing.Point(230, 493);
            this.jogador.Name = "jogador";
            this.jogador.Size = new System.Drawing.Size(72, 73);
            this.jogador.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.jogador.TabIndex = 0;
            this.jogador.TabStop = false;
            this.jogador.Click += new System.EventHandler(this.jogador_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 28);
            this.label1.TabIndex = 7;
            this.label1.Text = "Vida: ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(55, 3);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(136, 23);
            this.progressBar1.TabIndex = 8;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click_1);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImage = global::ProjetoFinalHenriqueAntonio11F.Properties.Resources.fundin;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(525, 578);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.scoretext);
            this.Controls.Add(this.perdeutext);
            this.Controls.Add(this.bala);
            this.Controls.Add(this.enemy3);
            this.Controls.Add(this.enemy2);
            this.Controls.Add(this.enemy1);
            this.Controls.Add(this.jogador);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Stars of Astagri";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PlayerMovement);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.PlayerMove);
            ((System.ComponentModel.ISupportInitialize)(this.bala)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jogador)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox jogador;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Label scoretext;
        private System.Windows.Forms.PictureBox enemy1;
        private System.Windows.Forms.PictureBox enemy2;
        private System.Windows.Forms.PictureBox enemy3;
        private System.Windows.Forms.PictureBox bala;
        private System.Windows.Forms.Label perdeutext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}